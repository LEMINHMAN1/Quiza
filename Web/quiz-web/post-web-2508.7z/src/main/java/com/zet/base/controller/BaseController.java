package com.zet.base.controller;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.zet.base.adapter.BaseAdapter;
import com.zet.base.model.BaseModel;
import com.zet.business.entities.Album;
import com.zet.business.entities.Collect;
import com.zet.business.manager.TransactionManager;
import com.zet.enumerator.PageType;
import com.zet.general.controller.CommonController;

/**
 * 
 * @author man le
 *
 */
@Controller()
public class BaseController extends CommonController{

//	private final static Logger logger = Logger.getLogger(BaseController.class);
	
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/index.htm", method = RequestMethod.GET)
	public ModelAndView indexGet(
			@ModelAttribute BaseModel baseModel,
			ModelMap modelMap
			){
		
//		List<Album> albums = transactionManager.read(READ_ALBUM,
//                null,
//                new Class[] { Album.class });
//		
//		BaseModel baseModelResponse = BaseAdapter.adaptAlbum(albums);
//		modelMap.addAttribute(BaseModel.class.getSimpleName(), baseModelResponse);
		
		ModelAndView model = new ModelAndView(PageType.BASE.getPageName(),modelMap);
		
		return model;
 
	}
	
}

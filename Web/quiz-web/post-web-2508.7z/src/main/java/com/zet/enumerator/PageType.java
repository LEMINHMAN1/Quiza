package com.zet.enumerator;

import java.util.EnumSet;

/**
 * 
 * @author man le
 *
 */
public enum PageType {
	
	BASE("base/base",0),
	MUSIC("music/music",1),
	;
	
	private static EnumSet<PageType> pageTypes=  EnumSet.allOf(PageType.class);
	
	private String pageName;
	private int pageCode;
	
	PageType(String pageName,int pageCode){
		this.setPageName(pageName);
		this.pageCode=pageCode;
		
	}

	public int getPageCode() {
		return pageCode;
	}

	public void setPageCode(int pageCode) {
		this.pageCode = pageCode;
	}
	
	public static PageType getPageType(int code){
		PageType result = PageType.BASE;
		for(PageType pageType:pageTypes){
			if(pageType.getPageCode()==code){
				result = pageType;
				break;
			}
		}
		return result;
	}

	public String getPageName() {
		return pageName;
	}

	public void setPageName(String pageName) {
		this.pageName = pageName;
	}
}

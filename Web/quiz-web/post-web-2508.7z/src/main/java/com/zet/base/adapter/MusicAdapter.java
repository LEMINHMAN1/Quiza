package com.zet.base.adapter;

import java.util.ArrayList;
import java.util.List;

import com.zet.base.model.BaseModel;
import com.zet.business.entities.Album;
import com.zet.business.entities.AlbumType;
import com.zet.business.entities.Collect;
import com.zet.general.model.DropdownModel;
import com.zet.music.model.MusicModel;

/**
 * 
 * @author man le
 *
 */
public class MusicAdapter {

	public static MusicModel adaptMusic(final List<Collect> collects, final long dfSound){
		MusicModel musicModel = new MusicModel();
		
		List<Collect> musics = new ArrayList<Collect>();
		List<DropdownModel> ddrSound = new ArrayList<DropdownModel>();
		List<Collect> places = new ArrayList<Collect>();
		
		for(Collect collect: collects){
			
			AlbumType albumType = AlbumType.fromAlbumType(collect.getType());
			switch (albumType) {
			case MUSIC:
				musics.add(collect);
				break;
				
			case SOUND:
				DropdownModel ddrModel = new DropdownModel();
				ddrModel.setLabel(collect.getCollectName());
				ddrModel.setValue(collect.getUrl());
				if(collect.getAlbumId()==dfSound){
					ddrModel.setSelected(true);
				}else{
					ddrModel.setSelected(false);
				}
				ddrSound.add(ddrModel);
				break;
			
			case PLACE:
				places.add(collect);
				break;
			
			}
		}
		
		musicModel.setDdrSound(ddrSound);
		musicModel.setMusics(musics);
		musicModel.setPlaces(places);
		
		return musicModel;
	}
	
	public static BaseModel adaptCollect(final List<Collect> collects){
		BaseModel baseModel = new BaseModel();
		
		List<DropdownModel> ddrMusic = new ArrayList<DropdownModel>();
		List<DropdownModel> ddrSound = new ArrayList<DropdownModel>();
		List<DropdownModel> ddrPlace = new ArrayList<DropdownModel>();
		
		return baseModel;
	}
	
}

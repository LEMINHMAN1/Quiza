package com.zet.business.dao;

import java.util.List;

public interface BaseDAO<T> {

    public List<T> read(String queryName, Object[] param, Class[] entities);

    public Integer save(String queryName, Object[] param);
}
package com.zet.music.model;

import java.util.ArrayList;
import java.util.List;

import com.zet.business.entities.Collect;
import com.zet.general.model.DropdownModel;

/**
 *
 * @author man le
 *
 */
public class MusicModel {
	private List<Collect> musics = new ArrayList<Collect>();
	private List<DropdownModel> ddrSound = new ArrayList<DropdownModel>();
	private List<Collect> places = new ArrayList<Collect>();
	private long defaultSound;
	
	public List<Collect> getMusics() {
		return musics;
	}
	public void setMusics(List<Collect> musics) {
		this.musics = musics;
	}
	public List<DropdownModel> getDdrSound() {
		return ddrSound;
	}
	public void setDdrSound(List<DropdownModel> ddrSound) {
		this.ddrSound = ddrSound;
	}
	public List<Collect> getPlaces() {
		return places;
	}
	public void setPlaces(List<Collect> places) {
		this.places = places;
	}
	public long getDefaultSound() {
		return defaultSound;
	}
	public void setDefaultSound(long defaultSound) {
		this.defaultSound = defaultSound;
	}
	
}

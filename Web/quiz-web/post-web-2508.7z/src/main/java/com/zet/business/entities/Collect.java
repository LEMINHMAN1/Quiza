package com.zet.business.entities;

/**
 * 
 * @author man le
 *
 */
public class Collect {

	private long collectId;
	private String collectName;
	private Long albumId;
	private String url;
	private int type;
	private String author;
	
	public long getCollectId() {
		return collectId;
	}
	public void setCollectId(long collectId) {
		this.collectId = collectId;
	}
	public String getCollectName() {
		return collectName;
	}
	public void setCollectName(String collectName) {
		this.collectName = collectName;
	}
	public long getAlbumId() {
		return albumId;
	}
	public void setAlbumId(long albumId) {
		this.albumId = albumId;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public int getType() {
		return type;
	}
	public void setType(int type) {
		this.type = type;
	}
	/**
	 * @return the author
	 */
	public String getAuthor() {
		return author;
	}
	/**
	 * @param author the author to set
	 */
	public void setAuthor(String author) {
		this.author = author;
	}
	
	
}

package com.zet.business.entities;

/**
 * 
 * @author man le
 *
 */

public enum CollectType {
	MUSIC(1), SOUND(2), IMAGE(3);
	
	private int type;
	
	CollectType(int type){
		this.type=type;
	}
	public int getType(){
		return type;
	}
}

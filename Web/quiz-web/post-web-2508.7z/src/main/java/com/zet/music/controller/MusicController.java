package com.zet.music.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.zet.base.adapter.MusicAdapter;
import com.zet.business.entities.Collect;
import com.zet.enumerator.PageType;
import com.zet.general.controller.CommonController;
import com.zet.music.model.MusicModel;

/**
 * 
 * @author man le
 *
 */
@Controller()
public class MusicController extends CommonController {

	private final static Logger logger = Logger.getLogger(MusicController.class);

	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/music.htm/{dfMusic}/{dfSound}/{dfPlace}", method = RequestMethod.GET)
	public ModelAndView indexGet(HttpSession session,
			HttpServletResponse response,
			HttpServletRequest request,
			@PathVariable(value="dfMusic") long defaultMusic,
			@PathVariable(value="dfSound") long defaultSound,
			@PathVariable(value="dfPlace") long defaultPlace,
			ModelMap modelMap
			){

		List<Collect> collects = transactionManager.read(READ_COLLECT,
				new Long[]{defaultMusic,defaultPlace},
                new Class[] { Collect.class });
		
		MusicModel musicModelResponse = MusicAdapter.adaptMusic(collects,defaultSound);
		modelMap.addAttribute(MusicModel.class.getSimpleName(), musicModelResponse);
		
		ModelAndView model = new ModelAndView(PageType.MUSIC.getPageName(),modelMap);
		
		return model;
 
	}

}

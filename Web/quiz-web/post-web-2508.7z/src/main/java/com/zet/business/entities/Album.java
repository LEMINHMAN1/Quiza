package com.zet.business.entities;

/**
 * 
 * @author man le
 *
 */
public class Album {
	private Long albumId;
	private String name;
	private int type;
	public Long getAlbumId() {
		return albumId;
	}
	public void setAlbumId(Long albumId) {
		this.albumId = albumId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getType() {
		return type;
	}
	public void setType(int type) {
		this.type = type;
	}

}

package com.zet.general.controller;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.zet.business.manager.TransactionManager;

@Controller
public class CommonController {

    @SuppressWarnings("rawtypes")
    @Autowired
    @Resource(name = "transactionManager")
    protected TransactionManager transactionManager;
	
    protected static final String READ_ALBUM = "ReadAlbum";
    protected static final String READ_COLLECT="ReadCollect";
	
}

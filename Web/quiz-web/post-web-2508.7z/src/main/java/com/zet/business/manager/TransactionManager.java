package com.zet.business.manager;

import java.util.List;

import com.zet.framework.exception.ScyllaSQLException;

/**
 * 
 * @author manle
 * 
 */
public interface TransactionManager<T> {

    public List<T> read(String queryName, Object[] param, Class[] entities)
            throws ScyllaSQLException;

    public Integer save(String queryName, Object[] param) throws ScyllaSQLException;
}

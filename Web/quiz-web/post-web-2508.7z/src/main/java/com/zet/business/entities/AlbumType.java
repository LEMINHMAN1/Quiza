package com.zet.business.entities;

import java.util.EnumSet;



/**
 * 
 * @author man le
 *
 */
public enum AlbumType {
	MUSIC(1),SOUND(2),PLACE(3);
	
	private static EnumSet<AlbumType> albumTypes=  EnumSet.allOf(AlbumType.class);
	
	private int type;
	AlbumType(int type){
		this.type=type;
	}
	public int getType(){
		return type;
	}
	
	public static AlbumType fromAlbumType(int type){
		AlbumType result = AlbumType.MUSIC;
		for(AlbumType albumType:albumTypes){
			if(albumType.getType()==type){
				result = albumType;
				break;
			}
		}
		return result;
	}
}

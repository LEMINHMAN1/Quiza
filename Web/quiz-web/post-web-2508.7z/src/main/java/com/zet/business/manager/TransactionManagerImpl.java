package com.zet.business.manager;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.transaction.annotation.Transactional;

import com.zet.business.dao.BaseDAO;
import com.zet.framework.exception.ScyllaSQLException;

/**
 * 
 * @author manle
 * 
 */
@Transactional
public class TransactionManagerImpl<T> extends HibernateDaoSupport implements TransactionManager<T> {

    @SuppressWarnings("rawtypes")
    @Autowired
    @Resource(name = "baseDAO")
    protected BaseDAO baseDAO;

    @SuppressWarnings({ "unchecked", "rawtypes" })
    public List<T> read(String queryName, Object[] param, Class[] entities)
            throws ScyllaSQLException {

        return baseDAO.read(queryName, param, entities);
    }

    public Integer save(String queryName, Object[] param) throws ScyllaSQLException {

        return baseDAO.save(queryName, param);
    }
}

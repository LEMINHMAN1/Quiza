package com.zet.base.model;

import java.util.ArrayList;
import java.util.List;

import com.zet.general.model.DropdownModel;

/**
 * 
 * @author man le
 *
 */
public class BaseModel {

	/**
	 * Param of request : music
	 */
	private Long m;
	
	/**
	 * Param of request : sound
	 */
	private Long s;
	
	/**
	 * Param of request : place
	 */
	private Long p;
	
	private List<DropdownModel> ddrMusic = new ArrayList<DropdownModel>();
	private List<DropdownModel> ddrSound = new ArrayList<DropdownModel>();
	private List<DropdownModel> ddrPlace = new ArrayList<DropdownModel>();
	
	public List<DropdownModel> getDdrMusic() {
		return ddrMusic;
	}
	public void setDdrMusic(List<DropdownModel> ddrMusic) {
		this.ddrMusic = ddrMusic;
	}
	public List<DropdownModel> getDdrSound() {
		return ddrSound;
	}
	public void setDdrSound(List<DropdownModel> ddrSound) {
		this.ddrSound = ddrSound;
	}
	public List<DropdownModel> getDdrPlace() {
		return ddrPlace;
	}
	public void setDdrPlace(List<DropdownModel> ddrPlace) {
		this.ddrPlace = ddrPlace;
	}
	public Long getM() {
		return m;
	}
	public void setM(Long m) {
		this.m = m;
	}
	public Long getS() {
		return s;
	}
	public void setS(Long s) {
		this.s = s;
	}
	public Long getP() {
		return p;
	}
	public void setP(Long p) {
		this.p = p;
	}
	
}

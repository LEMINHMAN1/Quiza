package com.zet.base.adapter;

import java.util.ArrayList;
import java.util.List;

import com.zet.base.model.BaseModel;
import com.zet.business.entities.Album;
import com.zet.business.entities.AlbumType;
import com.zet.business.entities.Collect;
import com.zet.general.model.DropdownModel;

/**
 * 
 * @author man le
 *
 */
public class BaseAdapter {

	public static BaseModel adaptAlbum(final List<Album> albums){
		BaseModel baseModel = new BaseModel();
		
		List<DropdownModel> ddrMusic = new ArrayList<DropdownModel>();
		List<DropdownModel> ddrSound = new ArrayList<DropdownModel>();
		List<DropdownModel> ddrPlace = new ArrayList<DropdownModel>();
		for(Album album: albums){
			
			DropdownModel dropdownModel = new DropdownModel();
			dropdownModel.setLabel(album.getName());
			dropdownModel.setValue(album.getAlbumId().toString());
			
			AlbumType albumType = AlbumType.fromAlbumType(album.getType());
			switch (albumType) {
			case MUSIC:
				ddrMusic.add(dropdownModel);
				break;
				
			case SOUND:
				ddrSound.add(dropdownModel);
				break;
			
			case PLACE:
				ddrPlace.add(dropdownModel);
				break;
			
			}
		}
		
		baseModel.setDdrMusic(ddrMusic);
		baseModel.setDdrSound(ddrSound);
		baseModel.setDdrPlace(ddrPlace);
		
		return baseModel;
	}
	
	public static BaseModel adaptCollect(final List<Collect> collects){
		BaseModel baseModel = new BaseModel();
		
		List<DropdownModel> ddrMusic = new ArrayList<DropdownModel>();
		List<DropdownModel> ddrSound = new ArrayList<DropdownModel>();
		List<DropdownModel> ddrPlace = new ArrayList<DropdownModel>();
		
		return baseModel;
	}
}
